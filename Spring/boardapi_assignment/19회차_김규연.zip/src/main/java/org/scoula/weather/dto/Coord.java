package org.scoula.weather.dto;

import lombok.Data;

@Data
public class Coord{
	private Object lon;
	private Object lat;
}